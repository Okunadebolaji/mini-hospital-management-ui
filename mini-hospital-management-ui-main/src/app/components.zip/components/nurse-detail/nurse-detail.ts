import { Component, OnInit,Renderer2 } from '@angular/core';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { NurseAssignmentService } from '../../services/nurse-assignment';
import { NurseImageService } from '../../services/nurse-image.service';

@Component({
  selector: 'app-nurse-detail',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './nurse-detail.html',
  styleUrl: './nurse-detail.css'
})
export class NurseDetail implements OnInit {
  nurseId!: number;
  nurseName = '';
  assignments: any[] = [];
  loading = true;
  error = '';
  isDarkMode = false;
  nurseImageUrl: string | null = null;
  selectedFile: File | null = null;


  // New stats fields
  mostCommonReason = '';
  mostUsedRoom = '';

  constructor(
    private route: ActivatedRoute,
    private nurseAssignmentService: NurseAssignmentService,
    private renderer: Renderer2,
     private nurseImageService: NurseImageService
  ) {}

  ngOnInit(): void {
       // Detection of darkmode
    this.isDarkMode = document.body.classList.contains('dark-mode') || localStorage.getItem('theme') === 'dark';
    this.updateThemeClass();

    this.route.paramMap.subscribe(params => {
      this.nurseId = Number(params.get('id'));
      console.log('🆔 Loaded Nurse Detail for ID:', this.nurseId);
      this.loadAssignments();
       this.loadNurseImage();
    });
  }

  loadAssignments() {
    this.loading = true;
    this.error = '';
    console.log('🔍 Fetching assignments...');

    this.nurseAssignmentService.getAssignments().subscribe({
      next: (data) => {
        console.log('✅ API Response:', data);
        console.log('👩‍⚕️ Nurse ID from route:', this.nurseId);

        if (!Array.isArray(data)) {
          console.error('❌ Expected an array but got:', typeof data, data);
          this.error = 'Invalid response format from API.';
          this.loading = false;
          return;
        }

        // Filter data for this nurse
        this.assignments = data.filter(a => a.nurse?.nurseId === this.nurseId);
        console.log('🎯 Filtered Assignments:', this.assignments);

        if (this.assignments.length > 0) {
          this.nurseName = this.assignments[0].nurse.name;
          console.log('🧑‍⚕️ Nurse Name:', this.nurseName);

          // Calculate most common reason and room
          const reasons = this.assignments.map(a => a.admission.reasonForAdmission);
          const rooms = this.assignments.map(a => a.admission.roomNumber);

          this.mostCommonReason = this.findMostCommon(reasons);
          this.mostUsedRoom = this.findMostCommon(rooms);
        } else {
          console.warn('⚠️ No assignments found for this nurse.');
        }

        this.loading = false;
      },
      error: (err) => {
        console.error('💥 Error fetching assignments:', err);
        this.error = 'Failed to load nurse data. Check the console for details.';
        this.loading = false;
      },
      complete: () => {
        console.log('✅ Request completed.');
      }
    });



  }



  private findMostCommon(arr: string[]): string {
    if (!arr.length) return '—';
    const freq: Record<string, number> = {};
    arr.forEach(item => (freq[item] = (freq[item] || 0) + 1));
    return Object.entries(freq).sort((a, b) => b[1] - a[1])[0][0];
  }
  toggleDarkMode() {
    this.isDarkMode = !this.isDarkMode;
    localStorage.setItem('theme', this.isDarkMode ? 'dark' : 'light');
    this.updateThemeClass();
  }

  private updateThemeClass() {
    if (this.isDarkMode) {
      this.renderer.addClass(document.body, 'dark-mode');
    } else {
      this.renderer.removeClass(document.body, 'dark-mode');
    }
  }



loadNurseImage() {
  this.nurseImageService.getNurseImage(this.nurseId).subscribe({
    next: (blob) => {
      const reader = new FileReader();
      reader.onload = () => (this.nurseImageUrl = reader.result as string);
      reader.readAsDataURL(blob);
    },
    error: () => {
      this.nurseImageUrl = 'assets/default-avatar.png'; // fallback
    }
  });
}

onFileSelected(event: any): void {
  const file: File = event.target.files[0];
  if (!file) return;

  this.selectedFile = file; // ✅ store the selected file

  this.nurseImageService.uploadNurseImage(this.nurseId, this.selectedFile).subscribe({
    next: () => {
      alert('✅ Profile image updated successfully!');
      this.loadNurseImage(); // refresh image instantly
    },
    error: (err: any) => {
      console.error('Error updating profile image:', err);
      alert('❌ Failed to update profile image.');
    }
  });
}



calculateStats() {
  if (this.assignments.length > 0) {
    // Find most common reason and room
    const reasonCounts: Record<string, number> = {};
    const roomCounts: Record<string, number> = {};

    for (const a of this.assignments) {
      reasonCounts[a.admission.reasonForAdmission] = (reasonCounts[a.admission.reasonForAdmission] || 0) + 1;
      roomCounts[a.admission.roomNumber] = (roomCounts[a.admission.roomNumber] || 0) + 1;
    }

    this.mostCommonReason = Object.keys(reasonCounts).reduce((a, b) => reasonCounts[a] > reasonCounts[b] ? a : b);
    this.mostUsedRoom = Object.keys(roomCounts).reduce((a, b) => roomCounts[a] > roomCounts[b] ? a : b);
  }
}

}
