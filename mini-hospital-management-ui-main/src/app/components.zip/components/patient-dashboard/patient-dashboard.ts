import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PatientService } from '../../services/patients';
import { Patient } from '../../Models/patient-model.dto';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';

@Component({
  selector: 'app-patient-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './patient-dashboard.html',
  styleUrls: ['./patient-dashboard.css']
})
export class PatientDashboardComponent implements OnInit {
  patient: Patient | null = null;
  isEditing = false;

  constructor(
    private patientService: PatientService,
    private router: Router
  ) {}

  ngOnInit(): void {
    console.log('🔍 PatientDashboardComponent initialized');

    const user = JSON.parse(localStorage.getItem('user') || '{}');
    const userId = user?.userId;

    console.log('📨 Fetching patient by userId:', userId);

    if (!userId || isNaN(userId)) {
      console.warn('⚠️ Invalid or missing userId in localStorage');
      return;
    }

    this.patientService.getPatientByUserId(userId).subscribe({
      next: (data) => {
        console.log('✅ Patient data received:', data);
        this.patient = data;
      },
      error: (err) => {
        console.error('❌ Failed to load patient data:', err);
      }
    });
  }

  toggleEdit(): void {
    this.isEditing = !this.isEditing;
    console.log('✏️ Edit mode toggled:', this.isEditing);
  }

  updatePatient(): void {
    if (!this.patient) {
      console.warn('⚠️ No patient data to update');
      return;
    }

    console.log('📤 Updating patient:', this.patient);

    this.patientService.updatePatient(this.patient).subscribe({
      next: () => {
        alert('Profile updated successfully!');
        this.isEditing = false;
        console.log('✅ Patient update successful');

        // ✅ Redirect to main dashboard
        this.router.navigateByUrl('/patient-main-dashboard');
      },
      error: (err) => {
        alert('Update failed. Please try again.');
        console.error('❌ Patient update failed:', err);
      }
    });
  }

  goToMainDashboard(): void {
  this.router.navigateByUrl('/patient/main-dashboard');
}

}
