import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { AuthService } from '../../services/Auth';
import { ToastrService } from 'ngx-toastr';
import { DoctorAdmissionsService } from '../../services/doctor';
import { DomSanitizer } from '@angular/platform-browser';
import { PatientService } from '../../services/patients';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})
export class Login implements OnInit {
  form!: FormGroup;
  error = '';

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private router: Router,
    private toastr: ToastrService,
    private doctorService: DoctorAdmissionsService,
    private patientService: PatientService,
    private sanitizer: DomSanitizer
  ) {}

  ngOnInit() {
    this.form = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  login(): void {
    if (this.form.invalid) {
      this.toastr.error('Please fill in all fields', 'Validation Error');
      return;
    }

    const payload = this.form.value;

    this.auth.login(payload).subscribe({
      next: (res: any) => {
        console.log('Login response:', res);

        try {
          const normalizedMenu = (res.menu || []).map((item: any) => ({
            ...item,
            canView: item.canView ?? (item.canEdit || item.canDelete) ?? false,
            canEdit: item.canEdit ?? false,
            canDelete: item.canDelete ?? false
          }));
          localStorage.setItem('menu', JSON.stringify(normalizedMenu));
        } catch (e) {
          console.error('Failed to normalize and save menu:', e);
        }

        localStorage.setItem('authToken', res.token);
        localStorage.setItem('userRole', res.role);
        localStorage.setItem('userId', res.userId.toString());
        localStorage.setItem('userName', res.name);

        this.toastr.success(`Welcome ${res.name}`, 'Login Successful');

        switch (res.role) {
          case 'Admin':
            this.auth.setLogin(res.userId.toString(), 'Admin', res.token);
            this.router.navigate(['/admin/dashboard']);
            break;

          case 'Doctor':
          case 'Gynaecologist':
            this.doctorService.getDoctorByUserId(res.userId).subscribe({
              next: (doctor: any) => {
                localStorage.setItem('doctorId', doctor.doctorId.toString());
                localStorage.setItem('userName', doctor.name);

                this.doctorService.getDoctorProfileImage(doctor.doctorId).subscribe({
                  next: (blob) => {
                    const objectURL = URL.createObjectURL(blob);
                    const safeUrl = this.sanitizer.bypassSecurityTrustUrl(objectURL);
                    this.auth.setLogin(res.userId.toString(), res.role, res.token, safeUrl as string);
                  },
                  error: () => {
                    this.auth.setLogin(res.userId.toString(), res.role, res.token, 'assets/Images/avatar-1577909_1280.png');
                  }
                });

                const route = res.role === 'Doctor'
                  ? `/role/doctor/${doctor.doctorId}`
                  : '/role/gyn/dashboard';

                this.router.navigate([route]);
              },
              error: () => {
                this.toastr.error(`${res.role} profile not found`, 'Error');
              }
            });
            break;

          case 'Nurse':
            this.auth.setLogin(res.userId.toString(), 'Nurse', res.token);
            this.router.navigate(['/role/nurse/dashboard']);
            break;

          case 'Pharmacist':
            this.auth.setLogin(res.userId.toString(), 'Pharmacist', res.token);
            this.router.navigate(['/role/pharmacy/dashboard']);
            break;

          case 'Dentist':
            this.auth.setLogin(res.userId.toString(), 'Dentist', res.token);
            this.router.navigate(['/role/dentist/dashboard']);
            break;

          case 'Consultant':
            this.auth.setLogin(res.userId.toString(), 'Consultant', res.token);
            this.router.navigate(['/role/consult/dashboard']);
            break;

          case 'Patient':
            this.auth.setLogin(res.userId.toString(), 'Patient', res.token);
            this.router.navigate(['/role/patient/dashboard']);
            break;

          case 'Ophthalmologist':
            this.auth.setLogin(res.userId.toString(), 'Ophthalmologist', res.token);
            this.router.navigate(['/role/eye/dashboard']);
            break;

          default:
            this.auth.setLogin(res.userId.toString(), res.role, res.token);
            this.router.navigate(['/home']);
        }
      },
      error: (err) => {
        console.error('Login failed:', err);
        this.error = 'Invalid credentials';
        this.toastr.error(this.error, 'Login Failed');
      }
    });
  }
}
