import { Component, OnInit } from '@angular/core';
import { PatientService } from '../../services/patients';
import { Patient } from '../../Models/patient-model.dto';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { DoctorDashboardComponent } from '../doctor-dashboard/doctor-dashboard'; 

@Component({
  selector: 'app-patient-main-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule,DoctorDashboardComponent],
  templateUrl: './patient-main-dashboard.html',
  styleUrls: ['./patient-main-dashboard.css']
})
export class PatientMainDashboardComponent implements OnInit {
    patient: Patient | null = null;
  activeTab: string = 'viewDoctors';

  constructor(private patientService: PatientService) {}

  ngOnInit(): void {
    const userId = Number(localStorage.getItem('userId'));
    if (!userId || isNaN(userId)) return;

    this.patientService.getPatientByUserId(userId).subscribe({
      next: (data) => this.patient = data,
      error: () => alert('Failed to load dashboard.')
    });
  }
  switchTab(tab: string): void {
    this.activeTab = tab;
  }
}
