import { Component, OnInit } from '@angular/core';
import { DoctorAdmissionsService } from '../../services/doctor';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-doctor-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './doctor-dashboard.html',
  styleUrls: ['./doctor-dashboard.css']
})
export class DoctorDashboardComponent implements OnInit {
  doctors: any[] = [];

  constructor(private doctorService: DoctorAdmissionsService) {}

 ngOnInit(): void {
  this.doctorService.getDoctors().subscribe({
    next: (data) => {
      console.log('📦 Doctors received:', data);
      this.doctors = data;

      this.doctors.forEach(doc => {
        this.doctorService.getDoctorProfileImage(doc.doctorId).subscribe({
          next: (blob: Blob) => {
            doc.profileImageUrl = URL.createObjectURL(blob);
          },
          error: () => {
            doc.profileImageUrl = 'assets/Images/avatar-1577909_1280.png';
          }
        });
      });
    },
    error: (err) => {
      console.error('❌ Failed to load doctors:', err);
    }
  });
}

}
