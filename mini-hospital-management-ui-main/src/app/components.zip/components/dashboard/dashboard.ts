import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardMetrics } from './dashboard-metrics/dashboard-metrics';
import { DashboardChartsComponent } from './dashboard-charts/dashboard-charts';
import { DashboardPatientsComponent } from './dashboard-patients/dashboard-patients';
import { RouterModule } from '@angular/router';
import { DashboardService } from '../../services/dashboard';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, DashboardMetrics, DashboardChartsComponent, DashboardPatientsComponent, RouterModule],
  templateUrl: './dashboard.html',
  styleUrls: ['./dashboard.css']
})
export class DashboardComponent implements OnInit {
nextPatient: any;
approvals: any[] = [];


  metrics: any;

  constructor(private dashboardService: DashboardService) {}

  ngOnInit() {
    this.dashboardService.getAdminMetrics().subscribe(data => {
      this.metrics = data;
    });

    this.dashboardService.getNextPatient().subscribe(data => {
    this.nextPatient = data;
  });

  this.dashboardService.getApprovalRequests().subscribe(data => {
    this.approvals = data;
  });
  }


}
