import { Component,Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-metrics',
  imports: [],
  templateUrl: './dashboard-metrics.html',
  styleUrl: './dashboard-metrics.css'
})
export class DashboardMetrics implements OnInit{
  @Input() metrics: any;

ngOnInit(): void {


}

}
