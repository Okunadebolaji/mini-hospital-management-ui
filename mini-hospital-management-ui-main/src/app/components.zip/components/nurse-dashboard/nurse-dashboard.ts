import { Component, OnInit } from '@angular/core';
import { NurseAssignmentService } from '../../services/nurse-assignment';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-nurse-dashboard',
  standalone: true,
  imports: [CommonModule,RouterModule],
  templateUrl: './nurse-dashboard.html',
  styleUrl: './nurse-dashboard.css'
})
export class NurseDashboard implements OnInit {
assignments: any[] = [];
loading = true;   // 👈 added
  error: string | null = null;

 constructor(private nurseAssignmentService: NurseAssignmentService) {}

 ngOnInit(): void {
  this.nurseAssignmentService.getAssignments().subscribe({
    next: (data) => {
      console.log('Assignments loaded:', data);
      this.assignments = data;
    },
    error: (err) => console.error('Error fetching assignments:', err)
  });
}

}
