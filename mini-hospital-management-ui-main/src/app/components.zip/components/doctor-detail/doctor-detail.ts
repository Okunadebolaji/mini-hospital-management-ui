import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { DoctorAdmissionsService } from '../../services/doctor';
import { DoctorWithAdmissionsDto } from '../../Models/doctor-with-admissions.dto';
import { AdmissionDto } from '../../Models/Admission.dto';
import { DoctorService } from '../../services/doctor.service';

@Component({
  selector: 'app-doctor-detail',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './doctor-detail.html',
  styleUrls: ['./doctor-detail.css']
})
export class DoctorDetailComponent implements OnInit {
  doctor?: DoctorWithAdmissionsDto;
  loading = true;
  error?: string;
  profileImgUrl: string = '';
  doctorId!: number;

  constructor(
    private route: ActivatedRoute,
    private doctorService: DoctorAdmissionsService
  ) {}

  ngOnInit(): void {
    const idParam = this.route.snapshot.paramMap.get('id');
    const id = Number(idParam);

    if (Number.isNaN(id)) {
      this.error = 'Invalid doctor ID';
      this.loading = false;
      return;
    }

    this.doctorService.getDoctorWithAdmissionsById(id).subscribe({
      next: (doctor: DoctorWithAdmissionsDto) => {
        this.doctor = doctor;

        // ✅ Cache-busting image URL
        const timestamp = new Date().getTime();
        this.profileImgUrl = `https://localhost:7243/api/Doctor/${doctor.doctorId}/profile-image?${timestamp}`;

        this.loading = false;
      },
      error: (err) => {
        this.error = 'Failed to load doctor data';
        this.loading = false;
        console.error(err);
      }
    });
  }

  get totalAdmissions(): number {
    return this.doctor?.admissions.length ?? 0;
  }

  get mostCommonReason(): string {
    const reasons = this.doctor?.admissions.map((a: AdmissionDto) => a.reason) ?? [];
    const freq: Record<string, number> = {};
    reasons.forEach((r: string) => freq[r] = (freq[r] || 0) + 1);
    return Object.entries(freq).sort((a, b) => b[1] - a[1])[0]?.[0] ?? 'N/A';
  }

  get mostUsedRoom(): string {
    const rooms = this.doctor?.admissions.map((a: AdmissionDto) => a.room) ?? [];
    const freq: Record<string, number> = {};
    rooms.forEach((r: string) => freq[r] = (freq[r] || 0) + 1);
    return Object.entries(freq).sort((a, b) => b[1] - a[1])[0]?.[0] ?? 'N/A';
  }

 getProfileImageUrl(): string {
  return `https://localhost:7243/api/doctor/${this.doctorId}/profile-image?ts=${Date.now()}`;
}


}
